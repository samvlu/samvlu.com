//
//  ViewController.swift
//  TapCounter01
//
//  Created by Sam Lu on 10/1/16.
//  Copyright © 2016 sam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // MARK: - View Did Load
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    // MARK: - Outlets
    @IBOutlet weak var countLabel: UILabel!

    // MARK: - Properties
    var count = 0
    
    // MARK: - Interactions
    @IBAction func tapCounter(_ sender: UIButton) {
        count = count + 1
        countLabel.text = String(count)
    }
    
    @IBAction func tapResetButton(_ sender: UIBarButtonItem) {
        countLabel.text = "0"
        count = 0
    }

}














